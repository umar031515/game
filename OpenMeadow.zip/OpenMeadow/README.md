# Open Meadow (Android)

Native Android wrapper (WebView) around the Open Meadow game. three.js is bundled, so it runs fully offline.

## Get the APK

**Option A: GitHub (no installs)**
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab, then **Build APK**, then run it (it also runs on every push).
3. When it finishes, download the `OpenMeadow-apk` artifact and unzip it to get `app-release.apk`.

**Option B: Android Studio**
Open this folder, let it sync, then **Build > Build APK(s)**.

**Option C: Command line** (JDK 17, Android SDK, Gradle 8.7)
```
gradle assembleRelease
```
APK: `app/build/outputs/apk/release/app-release.apk`

## Install
Copy the APK to your phone, open it, and allow "Install unknown apps" when prompted.

The game is `app/src/main/assets/index.html`; edit it and rebuild to change anything.
